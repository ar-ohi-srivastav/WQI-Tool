import xlrd
import matplotlib.pyplot as plt
import math
import pandas as pd

def isvalid(input_list):
    for i in range(29):
        if input_list[i]==0.00:
            return False
    return True

book = xlrd.open_workbook("Bhadra river_Qual2k_tutorial.xlsx")
sheet = book.sheet_by_name("WQ Min")

X,DO,PH,BOD,NO3,ISS,TKN=[],[],[],[],[],[],[]
for i in range(sheet.nrows):
    X.append(sheet.cell_value(i, 2))
    DO.append(sheet.cell_value(i, 5))
    PH.append(sheet.cell_value(i, 17))
    BOD.append(sheet.cell_value(i, 7))
    NO3.append(sheet.cell_value(i, 10))
    ISS.append(sheet.cell_value(i, 4))
    TKN.append(sheet.cell_value(i, 22))

X.reverse()
DO.reverse()
PH.reverse()
BOD.reverse()
NO3.reverse()
ISS.reverse()
TKN.reverse()
available_parametres = 0
X=X[:29]
DO=DO[:29]
PH=PH[:29]
BOD=BOD[:29]
NO3=NO3[:29]
ISS=ISS[:29]
TKN=TKN[:29]


WQI=[]
for i in range(29):
    WQI.append(0) #initialise all zeroes
if(isvalid(DO)):
    available_parametres+=1
    for i in range(29):
        if DO[i] > 6.5:
            WQI[i]+=1
        elif DO[i]<6.5 and DO[i]>4.6 :
            WQI[i]+=3
        elif DO[i]>2.0 and DO[i]<4.5:
            WQI[i]+=6
        else:
            WQI[i]+=10
if(isvalid(PH)):
    available_parametres+=1
    for i in range(29):
        WQI[i]+=math.exp(abs(PH[i]-7)/1.082)

    
if(isvalid(BOD)):
    available_parametres+=1
    for i in range(29):
        if BOD[i]<2:
            WQI[i]+=1
        else:
            WQI[i]+=(BOD[i]/1.5)

if(isvalid(NO3)):
    available_parametres+=1
    for i in range(29):
        if NO3[i]<=20:
            WQI[i]+=1
        elif NO3[i]>20 and NO3[i]<=50:
            WQI[i]+=math.exp((NO3[i]-154.16)/76.28)
        else:
            WQI[i]+=NO3[i]/65
if(isvalid(ISS)):
    available_parametres+=1
    for i in range(29):
        if ISS[i]<20:
            WQI[i]+=1
        elif ISS[i]>=20 and ISS[i]<=49:
            WQI[i]+=3
        elif ISS[i]>=50 and ISS[i]<=100:
            WQI[i]+=6
        else:
            WQI[i]+=6
if(isvalid(TKN)):
    available_parametres+=1
    if TKN[i]<0.5:
        WQI[i]+=1
    elif TKN[i]>=0.5 and TKN[i]<=0.99:
        WQI[i]+=3
    elif TKN[i]>=1 and TKN[i]<=3:
        WQI[i]+=6
    else:
        WQI[i]+=10

if available_parametres!=0:
    for i in range(29):
        WQI[i]/=available_parametres
print(available_parametres)


lati = [13.237427429986727,13.234040650475047,13.226919318280471,13.220373186780114,13.214565088368953,13.209190537893152,13.202488219926257,13.197979882164974,13.204199660056243,13.20656548986791,13.2090096824253,13.209360789506652,13.208455155125018,13.212175201036517,13.207610822217017,13.20642373534999,13.21205068516866,13.216272243753368,13.212373922603481,13.212117561916477,13.211156206948843,13.205903519459017,13.205622072528882,13.208648306591009,13.21453625854513,13.222051341483827,13.22633959984309,13.224559104069446,13.229699936702014]
longi = [75.17831168101472,75.17587879338807, 75.17499314466153,75.1772472340153,75.18193615624256,75.18547529923937,75.19082317213109,75.19550484036917,75.1987411281844,75.20651798069647,75.21353680461323,75.22146822096458,75.22930231931599,75.23598577559122,75.24272361551832,75.25166255936001,75.25454984089461,75.2569513055011,75.26157104785175,75.2664455344316,75.27377873133574,75.28094305301288,75.28930667573731,75.29571248943518,75.30031505813517,75.30381564354727,75.31158104684977,75.31623513670458,75.32045129566491]
finallist=[]
for i in range(29):
    temp = {"lat":lati[i],"lng":longi[i],"color":0,"WQI":WQI[i]} # default set to polluted
    if(available_parametres==0):
        continue
    if WQI[i]<2.0:

        temp["color"]=0
    elif WQI[i]<=3.0 and WQI[i]>=2.0:
        temp["color"]=1
    elif WQI[i]>3.0 and WQI[i]<6.0:
        temp["color"]=2
    else:
        temp["color"]=3
    finallist.append(temp)

#  ADDING ESTIMATED VALUES USING INTERPOLATION----------------------------------------------------------------------------------------------

def addMid(arr):
    x=len(arr)
    temp=[]
    for i in range(x):
        temp.append(None)
        temp.append(arr[i])
    return temp[1:]

X= addMid(X)
DO=addMid(DO)
PH=addMid(PH)
BOD=addMid(BOD)
NO3=addMid(NO3)
ISS=addMid(ISS)
TKN=addMid(TKN)
available_parametres = 0


for i in range(len(X)):
    if i%2==1:
        X[i]=(X[i-1]+X[i+1])/2

df=pd.DataFrame({})

df["Distance"] = X
df["DO"] = DO
df["PH"] = PH
df["BOD"] = BOD
df["NO3"] = NO3
df["ISS"] = ISS
df["TKN"] = TKN

df=df.interpolate(method ='linear', limit_direction ='forward')
# print("\n After interpolation")
# print(df)

X= df["Distance"].tolist()
DO= df["DO"].tolist()
PH=df["PH"].tolist()
BOD=df["BOD"].tolist()
NO3=df["NO3"].tolist()
ISS=df["ISS"].tolist()
TKN=df["TKN"].tolist()


WQI=[]
for i in range(len(X)):
    WQI.append(0) #initialise all zeroes
if(isvalid(DO)):
    available_parametres+=1
    for i in range(len(X)):
        #temp = 0
        if DO[i] > 6.5:
            WQI[i]+=1
        elif DO[i]<6.5 and DO[i]>4.6 :
            WQI[i]+=3
        elif DO[i]>2.0 and DO[i]<4.5:
            WQI[i]+=6
        else:
            WQI[i]+=10
if(isvalid(PH)):
    available_parametres+=1
    for i in range(len(X)):
        WQI[i]+=math.exp(abs(PH[i]-7)/1.082)

    
if(isvalid(BOD)):
    available_parametres+=1
    for i in range(len(X)):
        if BOD[i]<2:
            WQI[i]+=1
        else:
            WQI[i]+=(BOD[i]/1.5)

if(isvalid(NO3)):
    available_parametres+=1
    for i in range(len(X)):
        if NO3[i]<=20:
            WQI[i]+=1
        elif NO3[i]>20 and NO3[i]<=50:
            WQI[i]+=math.exp((NO3[i]-154.16)/76.28)
        else:
            WQI[i]+=NO3[i]/65
if(isvalid(ISS)):
    available_parametres+=1
    for i in range(len(X)):
        if ISS[i]<20:
            WQI[i]+=1
        elif ISS[i]>=20 and ISS[i]<=49:
            WQI[i]+=3
        elif ISS[i]>=50 and ISS[i]<=100:
            WQI[i]+=6
        else:
            WQI[i]+=6
if(isvalid(TKN)):
    available_parametres+=1
    if TKN[i]<0.5:
        WQI[i]+=1
    elif TKN[i]>=0.5 and TKN[i]<=0.99:
        WQI[i]+=3
    elif TKN[i]>=1 and TKN[i]<=3:
        WQI[i]+=6
    else:
        WQI[i]+=10

if available_parametres!=0:
    for i in range(len(X)):
        WQI[i]/=available_parametres

lati=[13.237427429986727, 13.235922613451873, 13.234040650475047, 13.23031215355245, 13.226919318280471, 13.222898338783157, 13.220373186780114, 13.216737268471704, 13.214565088368953, 13.211430200020935, 13.209190537893152, 13.205691931951886, 13.202488219926257, 13.199417786212562, 13.197979882164974, 13.201669976095491, 13.204199660056243, 13.20529788285217, 13.20656548986791, 13.208714339613136, 13.2090096824253, 13.208826524794544, 13.209360789506652, 13.206976980393355, 13.208455155125018, 13.211094856086119, 13.212175201036517, 13.209322996395898, 13.207610822217017, 13.206942968710647, 13.20642373534999, 13.207719117102712, 13.21205068516866, 13.215423925038094, 13.216272243753368, 13.211593775969526, 13.212373922603481, 13.213687537479448, 13.212117561916477, 13.214142270477, 13.211156206948843, 13.207973330066965, 13.205903519459017, 13.206701621484916, 13.205622072528882, 13.206387140958373, 13.208648306591009, 13.210744203671483, 13.21453625854513, 13.217798662207743, 13.222051341483827, 13.224103767060283, 13.22633959984309, 13.222761456725038, 13.224559104069446, 13.228585480913933,13.229699936702014]
longi=[75.17831168101472, 75.17673710658472, 75.17587879338807, 75.17370791073228, 75.17499314466153, 75.17412589599361, 75.1772472340153, 75.17905183504173, 75.18193615624256, 75.18295587993802, 75.18547529923937, 75.18836087763546, 75.19082317213109, 75.1927076730968, 75.19550484036917, 75.19711247885488, 75.1987411281844, 75.20290921268193, 75.20651798069647, 75.2100660840409, 75.21353680461323, 75.21629642680529, 75.22146822096458, 75.2254368931755, 75.22930231931599, 75.23253904991675, 75.23598577559122, 75.23992490193436, 75.24272361551832, 75.24785755879765, 75.25166255936001, 75.25499680609171, 75.25454984089461, 75.25498731658584, 75.2569513055011, 75.25857193325349, 75.26157104785175, 75.26340102239574, 75.2664455344316, 75.27092020738954, 75.27377873133574, 75.2782366432867, 75.28094305301288, 75.28497355288538, 75.28930667573731, 75.29236236134916, 75.29571248943518, 75.29880562645859, 75.30031505813517, 75.30268493007932, 75.30381564354727, 75.30903843078372, 75.31158104684977, 75.31304644955793, 75.31623513670458, 75.31668181674928,75.32045129566491]

EstFinalList=[]

for i in range(len(X)):
    temp = {"lat":lati[i],"lng":longi[i],"color":0,"WQI":WQI[i]} # default set to polluted
    if(available_parametres==0):
        continue
    if WQI[i]<2.0:

        temp["color"]=0
    elif WQI[i]<=3.0 and WQI[i]>=2.0:
        temp["color"]=1
    elif WQI[i]>3.0 and WQI[i]<6.0:
        temp["color"]=2
    else:
        temp["color"]=3
    EstFinalList.append(temp)

