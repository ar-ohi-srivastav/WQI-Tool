# Video tutorial

    https://youtu.be/fE3nIWqt8Tk

# Reference

    - Create react app: https://create-react-app.dev/
    - SASS: https://sass-lang.com/
    - Boxicons: https://boxicons.com/
    - Google font: https://fonts.google.com/

# Preview

!["React animated sidebar indicator"](https://user-images.githubusercontent.com/67447840/150512429-b22b0236-7f13-43b3-bbdd-b466ea81f173.gif "React animated sidebar indicator")