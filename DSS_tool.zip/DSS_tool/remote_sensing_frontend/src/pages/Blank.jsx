const Blank = () => {
    return <div></div>;
};

export default Blank;
