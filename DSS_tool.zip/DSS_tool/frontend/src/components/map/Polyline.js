import { Component } from 'react'
import axios from 'axios';
export default class Polyline extends Component { 
  constructor(props){
        super(props);
        this.state={rows:[],
                  };
    }
  componentDidMount(){
        var row=[]
        var row1=[]
        var res={}
        axios({
            method: 'get',
            url: 'http://localhost:5000/check'
        })
        .then(resData=>resData.data)
        .then(res => {
            console.log(res);

        for (var i=0;i<res.river_locations.length;i++){
            row.push(
            res.river_locations[i].color
            ) }
        console.log(row)    
        this.setState({rows:row});     
       });
}        
  renderPolylines () {
    const { markers,markers1,res,map,maps,markers2,markers3,markers4,markers5,markers6,markers7,markers8,markers9,markers10,markers11,markers12,markers13,markers14,markers15,markers16,markers17,markers18,markers19,markers20,markers21,markers22,markers23,markers24,markers25,markers26,markers27 } = this.props
    const {rows} =this.state
    var temp =rows[0]
    if(temp == "yellow")
     {var temp1='#FFFF00'
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
  
   
    let nonGeodesicPolyline = new maps.Polyline({
      path: markers,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline.setMap(map)
    var temp =rows[1]
    if(temp=="yellow")
     {var temp1='#FFFF00'
     console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline1 = new maps.Polyline({
      path: markers1,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline1.setMap(map)

    //2
    var temp =rows[2]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline2 = new maps.Polyline({
      path: markers2,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline2.setMap(map)
    //3
    var temp =rows[3]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline3 = new maps.Polyline({
      path: markers3,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline3.setMap(map)
    //4
    var temp =rows[4]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline4 = new maps.Polyline({
      path: markers4,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline4.setMap(map)
    //5
    var temp =rows[5]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline5 = new maps.Polyline({
      path: markers5,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline5.setMap(map)
    //6
    var temp =rows[6]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline6 = new maps.Polyline({
      path: markers6,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline6.setMap(map)
    //7
    var temp =rows[7]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline7 = new maps.Polyline({
      path: markers7,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline7.setMap(map)
    //8
    var temp =rows[8]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline8 = new maps.Polyline({
      path: markers8,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline8.setMap(map)
    //9
    var temp =rows[9]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline9 = new maps.Polyline({
      path: markers9,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline9.setMap(map)
    //10
    var temp =rows[10]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline10 = new maps.Polyline({
      path: markers10,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline10.setMap(map)
    //11
    var temp =rows[11]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline11 = new maps.Polyline({
      path: markers11,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline11.setMap(map)
    //12
    var temp =rows[12]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline12 = new maps.Polyline({
      path: markers12,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline12.setMap(map)
    //13
    var temp =rows[13]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline13 = new maps.Polyline({
      path: markers13,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline13.setMap(map)
    //14
    var temp =rows[14]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline14 = new maps.Polyline({
      path: markers14,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline14.setMap(map)
    //15
    var temp =rows[15]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline15 = new maps.Polyline({
      path: markers15,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline15.setMap(map)
    //16
    var temp =rows[16]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline16 = new maps.Polyline({
      path: markers16,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline16.setMap(map)
    //17
    var temp =rows[17]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline17 = new maps.Polyline({
      path: markers17,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline17.setMap(map)
    //18
    var temp =rows[18]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline18 = new maps.Polyline({
      path: markers18,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline18.setMap(map)
    //19
    var temp =rows[19]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline19 = new maps.Polyline({
      path: markers19,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline19.setMap(map)
    //20
    var temp =rows[20]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline20 = new maps.Polyline({
      path: markers20,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline20.setMap(map)
    //21
    var temp =rows[21]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline21 = new maps.Polyline({
      path: markers21,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline21.setMap(map)
    //22
    var temp =rows[22]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline22 = new maps.Polyline({
      path: markers22,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline22.setMap(map)
    //23
    var temp =rows[23]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline23 = new maps.Polyline({
      path: markers23,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline23.setMap(map)
    //24
    var temp =rows[24]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline24 = new maps.Polyline({
      path: markers24,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline24.setMap(map)
    //25
    var temp =rows[25]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else if(temp=="green"){
      var temp1 = '#008000'
      console.log(temp1)
    }
    
    let nonGeodesicPolyline25 = new maps.Polyline({
      path: markers25,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline25.setMap(map)
    //26
    var temp =rows[26]
    if(temp=="yellow")
     {var temp1='#FFFF00'
    // console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline26 = new maps.Polyline({
      path: markers26,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline26.setMap(map)
    //27
    var temp =rows[27]
    console.log(temp)    
    if(temp=="yellow")
     {var temp1='#FFFF00'
     console.log(temp1)
    }
    else if(temp == "orange"){
      var temp1 = '#FFA500'
    }
    else if(temp=="red"){
      var temp1 = '#FF0000'

    }
    else {
      var temp1 = '#008000'

    }
    
    let nonGeodesicPolyline27 = new maps.Polyline({
      path: markers27,
      geodesic: false,
      strokeColor: temp1,
      strokeOpacity: 0.7,
      strokeWeight: 10
    })
    nonGeodesicPolyline27.setMap(map)
  }

  render () {
    this.renderPolylines()
    return null
  }
}