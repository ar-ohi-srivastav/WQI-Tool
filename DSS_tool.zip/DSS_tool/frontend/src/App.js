import logo from './logo.svg';
import './App.css';
import Button from '@material-ui/core/Button';
function App() {
  localStorage.setItem('googlemap', 1);
  return (
    <Button variant="contained" color="primary">
      Hello World
    </Button>
  );
}

export default App;
